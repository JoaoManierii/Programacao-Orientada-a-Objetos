public interface MaquinaDeBebidas {
    String tipoDeBebida();
}
