public class Refrigerante implements MaquinaDeBebidas {
    @Override
    public String tipoDeBebida() {
        return "Refrigerante";
    }
}
