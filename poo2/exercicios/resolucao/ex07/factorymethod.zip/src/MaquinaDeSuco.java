public class MaquinaDeSuco implements MaquinaDeBebidas{
    @Override
    public String tipoDeBebida() {
        return "Maquina de Suco";
    }
}
