public class MaquinaDeRefri implements MaquinaDeBebidas{
    @Override
    public String tipoDeBebida() {
        return "Maquina de Refrigerante";
    }
}
