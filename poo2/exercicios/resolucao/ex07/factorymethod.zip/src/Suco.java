public class Suco implements MaquinaDeBebidas{
    @Override
    public String tipoDeBebida() {
        return "Suco";
    }
}
