public class MaquinaAmbev implements IMaquinaDeBebidas{

    public static IRefrigerante entregarRefrigerante() {
        return null;
    }
    public static ISuco entregarSuco() {
        return null;
    }
}
