public class DelValle extends MaquinaCocaColaCompany implements ISuco{

    public static String pegar() {
        return "Suco DelValle";
    }

}
