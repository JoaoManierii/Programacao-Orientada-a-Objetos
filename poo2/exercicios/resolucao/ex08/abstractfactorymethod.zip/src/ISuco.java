public interface ISuco {

    public static String pegarSuco() {
        return "Suco";
    }
}
