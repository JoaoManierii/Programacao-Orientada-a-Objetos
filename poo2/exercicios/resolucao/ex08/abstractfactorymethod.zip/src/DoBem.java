public class DoBem extends MaquinaAmbev implements ISuco{
    public static String pegar() {
        return "Suco DoBem";
    }
}
