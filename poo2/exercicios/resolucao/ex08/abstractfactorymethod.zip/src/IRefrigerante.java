public interface IRefrigerante {

    public static String pegarRefri() {
        return "Refrigerante";
    }
}
