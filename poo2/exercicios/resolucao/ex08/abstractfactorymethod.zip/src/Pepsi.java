public class Pepsi extends MaquinaAmbev implements IRefrigerante{
    public static String pegar() {
        return "Refrigerante Pepsi";

    }
}
