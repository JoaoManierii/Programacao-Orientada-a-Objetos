public class CocaColaNormal extends MaquinaCocaColaCompany implements IRefrigerante{

    public static String pegar() {
        return "Refrigerante Coca Cola Normal";
    }

}
