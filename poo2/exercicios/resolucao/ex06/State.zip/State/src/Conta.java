public class Conta {
    public float saldo;
    public String nome;

    public State check;

    public Conta() {
    }

    public Conta(float saldo, String nome, State check) {
        this.saldo = saldo;
        this.nome = nome;
        this.check = check;
    }

    public float sacar (float saldo) {
        this.saldo -= saldo;
        return saldo;
    }

    public float depositar(float saldo) {
        this.saldo += saldo;
        return saldo;
    }
}



