public class Prata implements State{
    public boolean checkStado(float saldo) {
        if (saldo < 1000.0f && saldo > 0 ) {
            saldo = saldo-1;
            System.out.println("Voce deve pagar uma taxa de R$ 1,00 por cada saque que realizar");
        }
        return true;
    }
    }

