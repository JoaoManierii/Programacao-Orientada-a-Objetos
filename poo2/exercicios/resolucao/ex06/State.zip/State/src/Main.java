public class Main {
    public static void main(String[] args) {

        Vermelho x = new Vermelho();
        Prata y = new Prata();
        Ouro z = new Ouro();

        Conta x1 = new Conta(0.0f,"Felipe",x);
        Conta x2 = new Conta(500.0f, "Brayan", y);
        Conta x3 = new Conta( 1500.0f,"Mauricio", z);

    }
}