public class Vermelho implements State{
    public boolean checkStado(float saldo) {
        if (saldo == 0) {
            System.out.println("Voce não esta permitido a realização de saques. Apenas depósitos");
        }
        return true;
    }
}
