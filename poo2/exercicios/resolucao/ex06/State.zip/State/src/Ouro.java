public class Ouro implements State {
    public boolean checkStado(float saldo) {
        if (saldo > 1000.0f ) {
            saldo = saldo*0.1f;
            System.out.println("Voce não paga taxa de saque e ainda ganha um rendimento imediato (0,1%) em cada depósito que realizar");
        }
        return true;
    }
}
