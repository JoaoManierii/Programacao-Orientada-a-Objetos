public interface State {
    public boolean checkStado(float saldo);

}
