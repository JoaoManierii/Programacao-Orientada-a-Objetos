public interface Comissao {
    public float comissao(float venda);
}
